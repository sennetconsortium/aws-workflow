import uuid

SUBMISSION_ID = str(uuid.UUID(int=2020))
ENDPOINT_ID = str(uuid.UUID(int=1234))
TASK_ID = str(uuid.UUID(int=1001))
