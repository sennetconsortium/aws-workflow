from globus_sdk.exc import GlobusAPIError


class FlowsAPIError(GlobusAPIError):
    """
    Error class to represent error responses from Flows.
    """
